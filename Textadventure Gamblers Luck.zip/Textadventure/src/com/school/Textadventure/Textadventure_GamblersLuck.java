package com.school.Textadventure;
import java.util.Scanner;

public class Textadventure_GamblersLuck {

	public static Scanner scanner = new Scanner(System.in);
	public static int heart = 20;
	public static int gameRunning = 0;
    public static int coins = 1;
    public static int coinCap = 100;
    public static int Etage = 1;
    public static int roomNumber = 0;
    public static int heartCap = 20 + (roomNumber*Etage)/2;
    public static int attackPlayer = 5;
    public static int combatTurn = 1;
    public static int Item = 0;
    public static int coinMultiplierActual =1;
    public static int coinMultiplier = 1;
    public static int coinDamageMultiplier = 1;
    public static int HeavyAttackMultiplier = 2;
    public static int DefenceGegner = 0;
    public static int HeavyAttack = attackPlayer*2;
    public static int HeavyActive = 0;
    public static int PaperCut = 0;
    public static int PaperCutMultiplier = 0;
    public static int CraneActive = 0;
    public static int damagePlayer = 0;
    public static int HpGegner = 1;
    public static int AttackGegner = 1;
    public static int FightWave = 1;
    public static int LootMultiplier = 1;
    public static int LootComplete = 0;
    public static int RoomDifficulty = 1;
    public static int BossBuffActive = 0;
    public static int BossBuff = 0;
    public static int damageGegner = AttackGegner+(BossBuffActive*BossBuff);
    public static int VodkaActive = 0;
    public static int BloodyMaryActive = 0;
    public static int DealerDefeated = 0;
	
	
	public static void begruessung() {
		System.out.println("Willst du ein Spiel spielen? (ja/nein)");
		
			
			String wanna = scanner.nextLine();
			
			
			if (wanna.equals("ja") ) {
				System.out.println("Gut dass du darauf vorbereitet bist\nmal sehen wie lange du es durchhälst...");
				gameRunning = 1;
			}
			else if (wanna.equals("nein")) {
				System.out.println("Zu schade,\ndu kommst hier sonst aber nicht raus ...");
				gameRunning = 1;
			}
			else {
				System.out.println("Das war keine option. \nAber egal, du währst so und so nicht rausgekommen...");
				gameRunning = 1;
		}
			
				
		System.out.println("\nDu wachst in einem dunklen Raum auf, \ndein Kopf tut weh und du merkst das du inmitten mehrerer noch schlafenden Leute ligst.");
		System.out.println("Eine robotisch klingende stimme erklärt dir folgendes:\n'Liebe mitspieler, Ihr seid zurzeit im größten Casino dass es je gab,\nund Ihr habt leider euer ganzes Geld verspielt! Und nicht nur das,\nIhr habt auch noch Schulden bei uns...");
		System.out.println("Ihr habt jetzt 2 möglichkeiten, entweder ihr bezahlt, oder ihr sterbt!'");
		System.out.println("");
		System.out.println("Vor dir öffnet sich ein Gang mit 2 Türen und du bemerkst, dass es sich warscheinlich um dein letztes glücksspiel handelt.");
		
	
	}
	//spieler bekommt am anfang text eingeblendet '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	
	public static void spielEndeGut() {
		System.out.printf("%n");
		System.out.printf("%nDu hast Kinpin & alle seine Schergen sowie Gauner Besiegt.");
		System.out.printf("%nWährend du nich Schaust, öffnet sich ein Rotes Portal unter ihm...");
		System.out.printf("%nEine Scharlachrote Hand kommt hinaus & zieht in mit hinein...");
		System.out.printf("%nDanach schließt sich das Portal.");
		System.out.printf("%n");
		System.out.printf("%nVielen dank fürs Spielen!");
	}
	//spiel wird beendet (Gut) '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	public static void spielEndeSchlecht() {
		System.out.printf("%n");
		System.out.printf("%nKinpin reisst dich von deinem Körper...");
		System.out.printf("%nDu sieht das sich hinter dir dein Körper mit einer Rauchwolke, %nsich in eine Blackjack - Karte verwandelt hat...");
		System.out.printf("%nEhe du dich versiehst bist du in einem Riesigem Bergwerk wo Tausende, nein, %n Zehntausende einen Nie endeden Berg Kohle abkarren...");
		System.out.printf("%n");
		System.out.printf("%nVielen dank fürs Spielen!");
	}
	//spiel wird beendet '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	
	public static void Etagen() {
		Etage++;
		if (Etage == 2 ) {
			System.out.printf("%n");
			System.out.printf("%nDu betretest den Roten Teppich");
			System.out.printf("%nDu fülst das die Gegner stärker geworden sind...");
		}else if (Etage == 3) {
			System.out.printf("%n");
			System.out.printf("%nDu betretest die Spielhalle");
			System.out.printf("%nDu fülst das die Gegner stärker geworden sind...");
			coinMultiplierActual = coinMultiplierActual + 1/2;
		}else if (Etage ==4) {
			System.out.printf("%n");
			System.out.printf("%nDu betretest den VIP Tisch");
			System.out.printf("%nDu fülst das die Gegner stärker geworden sind...");
			coinMultiplierActual = coinMultiplierActual + 1/2;
		}else if (Etage == 5) {
			System.out.printf("%n");
			System.out.printf("%nDu betretest das Theater");
			System.out.printf("%nDu fülst das die Gegner stärker geworden sind...");
			coinMultiplierActual = coinMultiplierActual + 1/2;
		}else if (Etage == 6) {
			System.out.printf("%n");
			System.out.printf("%nDu betretest die VIP - Lounge");
			System.out.printf("%nDu fülst das die Gegner stärker geworden sind...");
			coinMultiplierActual = coinMultiplierActual + 1/2;
		}else if (Etage == 7) {
			System.out.printf("%n");
			System.out.printf("%nDu betretst den King's Court");
			System.out.printf("%nDu fülst das die Gegner stärker geworden sind...");
			System.out.printf("%nMach auch sinn, immerhin ist es die letzte Etage...");
		}
			
		
	}
	//Code für die Etagen '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	public static void raumBetreten() {
		
		
		System.out.println("\nwelchen Raum wirst du betreten? (1 oder 2)?");
		 RoomDifficulty = scanner.nextInt();
		if (RoomDifficulty >= 3) { 
			System.out.printf("%nnummer invalide, nochmal wählen!");
			
		}
		
	}
	//Spieler muss einen raum auswählen '=fertig='
	//_______________________________________________________________________________________________________________________________________
 
	public static void GameOver() {
		System.out.printf("%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡤⠴⡿⠓⠶⠾⠿⠶⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                                                                                                                                    ⣀⣀⠀⠀⢀⣤⣤⣤⣶⣶⣷⣤⣀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡖⠋⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠷⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀     ⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣶⣶⠀⠀⠀⠀⣠⣾⣿⣿⡇⠀⣿⣿⣿⣿⠿⠛⠉⠉\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⣤⣤⣿⠖⠻⠷⡶⣮⡙⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀              ⠀    ⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⠀⠀⠀⠀⠀⢀⣿⣿⣶⡀⠀⠀⠀⠀⠀⣾⣿⣿⣿⡄⠀⢀⣴⣿⣿⣿⣿⠁⢸⣿⣿⣿⣀⣤⡀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠉⠀⠀⠀⠀⠀⠀⠀⢀⣚⡯⠉⠀⠀⠀⠀⠀⠀⠀⠉⠛⢷⣄⣀⣀⣀⣀⣠⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         ⠀⠀⠀⠀⠀⣠⣴⣶⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⣼⣿⣿⣿⣧⠀⠀⠀⠀⢰⣿⣿⣿⣿⣇⣠⣿⣿⣿⣿⣿⡏⢠⣿⣿⣿⣿⣿⡿⠗⠂\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠟⠀⠀⠀⠀⠀⠀⠀⢀⣰⠿⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠀⠉⠉⠛⠿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         ⠀⠀⠀⣰⣾⣿⣿⠟⠛⠉⠉⠉⠉⠋⠀⠀⠀⣰⣿⣿⣿⣿⣿⣇⣠⣤⣤⣿⣿⣿⢿⣿⣿⣿⣿⢿⣿⣿⡿⠀⣼⣿⣿⡟⠉⠁⢀⣀⡄\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠏⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⣾⣉⠳⠄⠀⠀⠀⠀⠀⠀⠀⠉⠻⢶⣄⠀⠀⠀⠀⠀⠀⠀⠀         ⠀⢀⣾⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣴⣿⣿⣿⣿⡿⣿⣿⣿⡏⠈⢿⣿⣿⠏⣾⣿⣿⠃⢠⣿⣿⣿⣶⣶⣿⣿⣿⡷⠦\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣅⡀⠉⠁⠀⠀⠀⠀⢠⣴⣤⡀⠀⠀⠀⠙⢷⣄⡀⠀⠀⠀⠀⠀       ⢠⣾⣿⡿⠀⠀⠀⣀⣠⣴⣶⣿⣿⡷⠀⣠⣿⣿⣿⣿⡿⠟⣿⣿⣿⣠⣿⣿⣿⠀⠀⠀⠀⠁⢸⣿⣿⡏⠀⣼⣿⣿⣿⠿⠛⠛⠉⠀⠀⠀⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡴⣿⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣳⣾⠿⠁⠀⠀⠀⠀⠀⠀⠻⠿⠿⠟⠀⠀⠀⠀⠀⠉⠻⣦⠀⠀⠀⠀       ⢸⣿⣿⠣⣴⣾⣿⣿⣿⣿⣿⣿⡿⠃⣰⣿⣿⣿⠋⠁⠀⠀⠸⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠸⠿⠿⠀⠀⠛⠛⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⠖⠋⠁⢀⣼⡧⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⢶⡿⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣠⣤⣴⡒⠒⠶⣤⣿⠀⠀⠀⠀      ⠸⣿⣿⣆⣉⣻⣭⣿⣿⣿⡿⠋⠀⠀⢿⣿⡿⠁⠀⠀⠀⠀⠀⠹⠟⠛⠛⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠏⠁⠀⢀⣠⣼⡟⠀⠀⠀⠀⠀⠀⠀⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣤⠀⠀⠀⠤⠖⠚⠉⠉⣀⡠⠤⠒⢲⡆⠁⢀⡴⢩⡿⢤⡀⠀⠀     ⠀⠙⠿⣿⣿⣿⣿⡿⠟⠋⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⢀⣴⠋⠀⢀⣴⠞⠋⠉⢸⡇⠀⠀⠀⠀⠀⠀⠀⢽⣟⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠴⠋⠀⠀⠀⠀⠀⢀⡠⠖⠋⠁⢀⣤⣾⣥⠤⠴⠛⠋⠉⠙⣆⠉⠢⡄ ⠀⠀⠀⠀⠀⠀  ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ⠀⠀⠀⠀⠀⠀⣀⣤⣤⣶⣶⣶⣶⣦⣄⠀⠀\r\n"
				+ "⠀⠀⠀⠀⠀⣠⠟⠁⢠⡾⠋⠁⠀⠀⠀⣼⡇⠀⡀⠀⠀⠀⠀⠀⢰⣿⣗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡔⠋⠀⠀⠀⢠⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠈⢆⠀⠈   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ⠀⠀⢀⣷⠄⣤⣤⣤⣤⣶⣾⣷⣴⣿⣿⣿⣿⠿⠿⠛⣻⣿⣿⣷⡄\r\n"
				+ "⠀⠀⠀⠀⣴⠋⢀⡴⠋⠀⠀⠀⠀⠀⠀⣿⠿⢛⣣⣄⣀⡀⠀⠀⠀⢨⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⢠⣄⣴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡆⠀   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣄⠀⣶⣶⣤⡀⠀⠀⠀⠀⠀⠀⢀⣴⣿⠋⢠⣿⣿⣿⠿⠛⠋⠉⠛⣿⣿⣿⠏⢀⣤⣾⣿⣿⡿⠋⠀\r\n"
				+ "⠀⠀⠀⣼⠇⢀⡟⠁⠀⠀⠀⠀⠀⠀⠰⣿⠀⠈⠈⢻⣟⠉⠉⠉⠉⠉⠛⠻⢶⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⢠⣶⠏⢸⠛⠛⠒⢲⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⠓⢹⣿⣿⣷⠀⠀⠀⠀⢀⣶⣿⡿⠁⠀⣾⣿⣿⣟⣠⣤⠀⠀⢸⣿⣿⣿⣾⣿⣿⣿⡟⠋⠀⠀⠀\r\n"
				+ "⠀⠀⢠⡟⠀⣸⠁⠀⠀⠀⠀⠀⠀⠀⢰⡟⠀⠀⠀⡀⣿⣷⣄⠀⠀⠀⠀⠀⠀⠙⠿⣿⣀⢀⣀⣤⣄⠀⠀⠀⠀⣀⣀⣾⣿⣿⣄⣠⣏⠀⠀⠀⠺⣯⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀⠀⠀⠀⠀⣠⣾⣿⣿⡿⠛⠉⠸⣿⣦⡈⣿⣿⣿⡇⠀⠀⣰⣿⣿⡿⠁⠀⢸⣿⣿⣿⣿⣿⠿⠷⢀⣿⣿⣿⣿⡿⠛⣿⣿⣿⡀⠀⠀⠀\r\n"
				+ "⠀⠀⣸⡇⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠸⣧⠘⣷⣤⢹⣄⢻⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠻⣯⣤⣴⣦⣾⠷⣿⡋⠀⠀⠈⠉⢹⣿⣦⣿⠛⢷⣬⣿⠁⠀⠀⠀⠀⠀⠀  ⠀⠀⠀⠀⢀⣼⣿⣿⡿⠋⠀⠀⠀⠀⣿⣿⣧⠘⣿⣿⣿⡀⣼⣿⣿⡟⠀⠀⢀⣿⣿⣿⠋⠁⠀⣀⣀⣼⣿⣿⡟⠁⠀⠀⠘⣿⣿⣧⠀⠀⠀\r\n"
				+ "⠀⠀⣿⡇⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣧⡏⠙⢿⠟⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣯⡀⠀⠀⠈⢿⡷⣦⡀⠀⢸⠀⠉⠀⠀⠀⢀⣀⣀⠀          ⠀⠀⠀⠀         ⣼⣿⣿⡟⠀⠀⠀⠀⠀⣠⣿⣿⣿⠀⢹⣿⣿⣿⣿⣿⡟⠀⠀⠀⣼⣿⣿⣷⣶⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠸⣿⣿⡆⠀⠀\r\n"
				+ "⠀⠀⢻⡇⢠⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡏⠀⣇⠘⡆⢳⣬⣿⡄⠀⠀⠀⠀⠀⠀⠀⡏⠀⠀⢳⡀⣀⡤⠤⡄⠀⠀⠀⠀⠀  ⢹⣿⣿⣇⠀⠀⢀⣠⣴⣿⣿⣿⡿⠀⠈⣿⣿⣿⣿⡟⠀⠀⠀⢰⣿⣿⣿⠿⠟⠛⠉⠁⠸⢿⡟⠀⠀⠀⠀⠀⠀⠀⠘⠋⠁⠀⠀\r\n"
				+ "⠀⠀⣸⡇⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⡾⢻⣶⠿⣶⡏⠉⠀⠀⠀⠀⠀⠀⠀⠀⢧⡀⠀⠀⠛⠁⠀⠀⠸⡀  ⠀⠀⠀⠀⠈⢻⣿⣿⣿⣾⣿⣿⣿⣿⣿⠟⠁⠀⠀⠸⣿⣿⡿⠁⠀⠀⠀⠈⠙⠛⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
				+ "⠀⠀⣿⠃⡾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠁⠀⠉⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⡀⠀⠀⠀⠀⠀⡰⠃⠀      ⠀⠀   ⠀⠉⠛⠿⠿⠿⠿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n"
				+ "⠀⣼⣏⡼⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢆⣀⣠⠔⠊⠁⠀⠀\r\n"
				+ "⣼⣿⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠀⠀⠀⠀⠀");
		System.out.printf("%n");
		System.out.printf("%n");
		System.out.printf("%n");
		System.out.printf("%n⠀⠀⠀⠀⠀⢀⣤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⢤⣤⣀⣀⡀⠀⠀⠀⠀⠀⠀\r\n"
				+ "⠀⠀⠀⠀⢀⡼⠋⠀⣀⠄⡂⠍⣀⣒⣒⠂⠀⠬⠤⠤⠬⠍⠉⠝⠲⣄⡀⠀⠀\r\n"
				+ "⠀⠀⠀⢀⡾⠁⠀⠊⢔⠕⠈⣀⣀⡀⠈⠆⠀⠀⠀⡍⠁⠀⠁⢂⠀⠈⣷⠀⠀\r\n"
				+ "⠀⠀⣠⣾⠥⠀⠀⣠⢠⣞⣿⣿⣿⣉⠳⣄⠀⠀⣀⣤⣶⣶⣶⡄⠀⠀⣘⢦⡀\r\n"
				+ "⢀⡞⡍⣠⠞⢋⡛⠶⠤⣤⠴⠚⠀⠈⠙⠁⠀⠀⢹⡏⠁⠀⣀⣠⠤⢤⡕⠱⣷\r\n"
				+ "⠘⡇⠇⣯⠤⢾⡙⠲⢤⣀⡀⠤⠀⢲⡖⣂⣀⠀⠀⢙⣶⣄⠈⠉⣸⡄⠠⣠⡿\r\n"
				+ "⠀⠹⣜⡪⠀⠈⢷⣦⣬⣏⠉⠛⠲⣮⣧⣁⣀⣀⠶⠞⢁⣀⣨⢶⢿⣧⠉⡼⠁\r\n"
				+ "⠀⠀⠈⢷⡀⠀⠀⠳⣌⡟⠻⠷⣶⣧⣀⣀⣹⣉⣉⣿⣉⣉⣇⣼⣾⣿⠀⡇⠀\r\n"
				+ "⠀⠀⠀⠈⢳⡄⠀⠀⠘⠳⣄⡀⡼⠈⠉⠛⡿⠿⠿⡿⠿⣿⢿⣿⣿⡇⠀⡇⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠙⢦⣕⠠⣒⠌⡙⠓⠶⠤⣤⣧⣀⣸⣇⣴⣧⠾⠾⠋⠀⠀⡇⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠈⠙⠶⣭⣒⠩⠖⢠⣤⠄⠀⠀⠀⠀⠀⠠⠔⠁⡰⠀⣧⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠲⢤⣀⣀⠉⠉⠀⠀⠀⠀⠀⠁⠀⣠⠏⠀\r\n"
				+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠛⠒⠲⠶⠤⠴⠒⠚⠁⠀⠀");
	}
	//Daten, Mechaniken & AI vom Würfel (Geg. Typ 1) '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	
	
	public static void GegnerWürfel() {
		HpGegner = 6*Etage*RoomDifficulty +2*roomNumber;
		System.out.printf("%nVor dir Erscheint ein Schwebender Würfel");
		int min = 1;
		int max = 6;
		int SeiteWürfel = (int)Math.floor(Math.random()*(max - min)) + min;
		AttackGegner = 5+ (Etage*RoomDifficulty)/2 +SeiteWürfel/2;
		System.out.printf("%nEr hat die Seite %d",SeiteWürfel);
	}
	//Daten, Mechaniken & AI vom Würfel (Geg. Typ 1) '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	public static void GegnerBodyguard() {
		HpGegner = 18*Etage*RoomDifficulty +2*roomNumber;
		AttackGegner = 2+ (Etage*RoomDifficulty)/2;
		System.out.printf("%nVor dir Erscheint ein Bodyguard");
	}
	//Daten, Mechaniken & AI vom Bodyguard (Geg. Typ 2) '=fertig='
	//______________________________________________________________________________________________________________________________________
	
	public static void GegnerBlackjackKarten() {
		HpGegner = 9*Etage*RoomDifficulty +2*roomNumber;
		AttackGegner = 4+ (Etage*RoomDifficulty)/2;
		int min = 1;
		int max = 5;
		int Deffence = (int)Math.floor(Math.random()*(max - min)) + min;
		System.out.printf("%nVor dir Erscheint ein Deck Blackjack - Karten");
		DefenceGegner = Deffence;
	}
	//Daten, Mechaniken & AI von den Blackjack Karten (Geg. Typ 3) '=fertig='
	//______________________________________________________________________________________________________________________________________
	
	public static void GegnerSlotMaschine() {
		HpGegner = 10*Etage*RoomDifficulty+ 2*roomNumber;
		AttackGegner = 3+ (Etage*RoomDifficulty)/2;
		System.out.printf("%nVor dir Erscheint eine Slot - Maschine");
		int min = 1;
		int max = 10;
		int OneHitChance = (int)Math.floor(Math.random()*(max - min)) + min;
		if (OneHitChance == 1) {
			HpGegner = 1;
		}
		
	}
	//Daten, Mechaniken & AI von der Slot-Maschine (Geg. Typ 4) '=fertig='
	//______________________________________________________________________________________________________________________________________
	
	public static void BossDealer() {
		if (Etage == 4 && DealerDefeated == 0) {
			heart = heartCap;
			Fight();
		HpGegner = 500 + 3*roomNumber;
		AttackGegner = 8;
		System.out.printf("%n");
		System.out.printf("%nVor dir Erscheint ein Riesiger Dealer, mit sicherheit mindestenz 3 meter Groß...");
		System.out.printf("%n(Dealer)=> Du bist es also, der hier Unruhe stiftet...");
		System.out.printf("%n(Dealer)=> Muss man hier alles selbst machen!?");
		Fight();
		}DealerDefeated = 1;
	}
	//Daten, Mechaniken & AI vom Boss - Dealer '=fertig='
	//______________________________________________________________________________________________________________________________________
	
	public static void BossKingPin() {
		if (Etage == 7) {
			heart = heartCap;
		HpGegner = 750 +3*roomNumber;
		AttackGegner = 15;
		System.out.printf("%n");
		System.out.printf("%n(Kingpin)=> Wo kommst den du her angekrochen?");
		System.out.printf("%n(Kingpin)=> Wusste ich doch das du Besonders warst...");
		System.out.printf("%n(Kingpin)=> Arbeite für mich...");
		System.out.printf("%n(Kingpin)=> Na wie wärs?");
		System.out.printf("%n(Kingpin)=> Alle deine Schulden sind abbezahl, ...");
		System.out.printf("%n(Kingpin)=> Im gegenzug verlange ich nur dass du hier Unterschreibst...");
		System.out.printf("%nEr hällt dir einen seltsam leuchtendes Dokument in einer anderen Sprache unter die Nase...");
		System.out.printf("%n(1 => Unterzeichne/2 => Zerreisse das Papier)");
		int antwort = scanner.nextInt();
		if (antwort == 1) {
			System.out.printf("%nDu unterzeichnest das Papier...");
			System.out.printf("%n(Kingpin)=> Ich dachte nicht das du so Dumm bist...");
			System.out.printf("%n(Kingpin)=> Hiermit gehört mir jetzt offiziell deine gesamten Besitztümer, ...");
			System.out.printf("%n(Kingpin)=> UND deine Seele...");
			System.out.printf("%n(Kingpin)=> Viel Spaß in der Hölle!");
			gameRunning = 2;
		}else {
		Fight();
		gameRunning = 3;
		} 
		}
	}
	//Daten, Mechaniken & AI vom Boss - Kinpin '=fertig='
	//______________________________________________________________________________________________________________________________________
	
	public static void coinSicherung() {
		if (coins < 0) {
			for (int pain = 1; pain <= 3; pain++) {
			--heart;
			}
			coins = 1;
		}
		coinGrenze();
	}
	//Stellt sicher, dass man keine Schulden machen kann '=fertig='
	//________________________________________________________________________________________________________________________________________
	
	public static void coinGrenze() {
		if (coins > coinCap) {
			
			coins = coinCap;
		}
		
	}
	//Stellt sicher, dass man keine Schulden machen kann '=fertig='
	//________________________________________________________________________________________________________________________________________
	
	public static void EnemyAttack() {
		heart = heart - damageGegner;
		
	}
	//Regelt kampf - Mechaniken vom gegner '=fertig='
	//________________________________________________________________________________________________________________________________________
	
	public static void HeartSafe() {
		if(heart < 0) {
			HpGegner = 0;
			FightWave = 0;
			heart = 0;
			GameOver();
		}
	}
	//
	//________________________________________________________________________________________________________________________________________
	
	
	
	public static void Items() {
		if (Item == 1 ) {
			coinCap = coinCap + 100;
			
		}// Coinbeutel
		if (Item == 2 ) {
			if (coins > 8) {
			PlayerAttack();
			coins = coins -8;
			}else {
				int antwort = 0;
				while (!((antwort==1)||(antwort==2))) {
					System.out.printf("%nDu hast nich genug Münzen für noch einen Zug!");	
					System.out.printf("%nwillst du trotzdem fortfahren? (1 => ja/2 => nein)");
					antwort = scanner.nextInt();
					if (antwort==1) {
						PlayerAttack();
						coinSicherung();
				
					}else if (antwort==2) {
						System.out.printf("%n");
					}else {
						System.out.printf("%nbitte gib eine richtige Antwort ein! (ja/nein)");
					}
				}
			}
			
		}// Billardkugel => man kann münzen einwerfen, um noch einen Zug zu bekommen
		if (Item == 3 ) {
			int min = 1;
			int max = 10;
			int HurtChance = (int)Math.floor(Math.random()*(max - min)) + min;
			if (HurtChance >= 5 )	{
				for (int pain = 0; pain >= 5; pain++) {
					heart--;
				}
			}else {
				damagePlayer = damagePlayer*10;
				PlayerAttack();
			}
			
			
		}// Zufallswürfel
		if (Item == 4) {
			for (int live = 0; live == 3; live++)	{
			heart++;
		}
			
		}//Zigarre
		if (Item == 5) {
			DefenceGegner = 0;
			
		}//PockerChips
		
		if (Item == 6) {
			CraneActive = 1;
			
		}//Papier - Kranich 
		
	}
	//Methode für Item & deren Mechaniken '=fertig='
	//______________________________________________________________________________________________________________________________________
	
	public static void PlayerHeavieAttack() {
		HeavyActive = 1;
		coins = coins - 3; 
		
	}
	//Zuständig für die Schwere Attacke '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	public static void PlayerDamage() {
		 damagePlayer = 
			    (attackPlayer + (HeavyActive*HeavyAttack*HeavyAttackMultiplier) + (coinDamageMultiplier*coins)+(CraneActive*(attackPlayer*PaperCutMultiplier)))-(DefenceGegner);
			    
		
	}
	//Zuständig für die Schwere Attacke '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	
	public static void PlayerAttack() {
		System.out.printf("%nWähle Attackentyp. %n(1 => Normal/2 => Schwer) %n");
		int antwort = scanner.nextInt();
		
		if (antwort == 2) {
			HeavyActive = 1;
			PlayerHeavieAttack();
			PlayerDamage();
			HpGegner = HpGegner - damagePlayer;
			HeavyActive = 0;
		}else if (antwort == 1) {
			HeavyActive = 0;
			PlayerDamage();
			HpGegner = HpGegner - damagePlayer;
		}else if (!(antwort==1||antwort==2)) {
			System.out.printf("%nDas war keine Gültige Eingabe!");
		}
	}
	//Regelt kampf - Mechaniken vom Player '=fertig='
	//________________________________________________________________________________________________________________________________________
	public static void StatBlockAnzeigen() {
		System.out.printf("%n");
		System.out.printf("%nDu hast %d Münzen", coins);
		System.out.printf("%nDu hast noch %d Herzen", heart);
		System.out.printf("%nDu bist auf der Etage %d", Etage);
		System.out.printf("%nDer gegner hat noch  %d HP", HpGegner);
		System.out.printf("%nDer Gegner hat %d Verteidigung", DefenceGegner);
		System.out.printf("%nEs ist die  %d Runde", combatTurn);
	}
	//Zeigt die im Kampf releventten Daten an '=fertig='
	//________________________________________________________________________________________________________________________________________
	
	public static void Fight() {
		
		
		while (HpGegner > 0) {
			coinGrenze();
			HeartSafe();
			StatBlockAnzeigen();
			PlayerAttack();
			coinSicherung();
			Items();
			coinSicherung();
			EnemyAttack();
			combatTurn ++;
		}
		
	}
	//Regelt den Kampf ablauf '=fertig='
	//_______________________________________________________________________________________________________________________________________

	public static void GegnerSpawn() {
		
		int min = 1;
		int max = 4;
		int typeGegner = (int)Math.floor(Math.random()*(max - min)) + min;
		
		int minWave = 1;
		int maxWave = 8;
		FightWave = (int)Math.floor(Math.random()*(maxWave - minWave)) + minWave;
		
		if (typeGegner == 1) {
			for (int life = 0; life == 10; life++) {
				heart++;
			}
			while (FightWave > 0) {
				heart = heartCap;
				GegnerWürfel();
				Fight();
				--FightWave;
				combatTurn = 0;
				Loot();
				coinMultiplier = 1;
			}if (BloodyMaryActive == 1) {
				for (int pain = 0; pain == 10; pain++) {
					heart--;
				}
			}
		} else if (typeGegner == 2) {
			for (int life = 0; life == 10; life++) {
				heart++;
			}
			while (FightWave > 0) {
				heart = heartCap;
				GegnerBodyguard();
				Fight();
				--FightWave;
				combatTurn = 0;
				Loot();
				coinMultiplier = 1;
			}for (int pain = 0; pain == 10; pain++) {
				heart--;
			}
		} else if (typeGegner == 3) {
			for (int life = 0; life == 10; life++) {
				heart++;
			}
			while (FightWave > 0) {
				heart = heartCap;
				GegnerBlackjackKarten();
				Fight();
				--FightWave;
				combatTurn = 0;
				Loot();
				coinMultiplier = 1;
			}for (int pain = 0; pain == 10; pain++) {
				heart--;
			}
		}else {
			while (FightWave > 0) {
				for (int life = 0; life == 10; life++) {
					heart++;
				}
				heart = heartCap;
				GegnerSlotMaschine();
				Fight();
				--FightWave;
				combatTurn = 0;
				Loot();
				coinMultiplier = 1;
			}for (int pain = 0; pain == 10; pain++) {
				heart--;
			}
		}
		
		
		
	}
	//Spawnd gegner im raum '=fertig='
	//________________________________________________________________________________________________________________________________________
	
	public static void npcHausmeister() {
		System.out.printf("%n(Hausmeister)=> ...");
		System.out.printf("%n(Hausmeister)=> Sag mal...");
		System.out.printf("%n(Hausmeister)=> Willst du wetten?...");
		System.out.printf("%n(1 => ja/2 => nein)");
		int antwort = scanner.nextInt();
		if (antwort == 1) {
			int min = 1;
			int max = 4;
			int Bet = (int)Math.floor(Math.random()*(max - min)) + min;
			
			if (Bet == 1) {
				System.out.printf("%n(Hausmeister)=> 25 Münzen  wenn du schon 8 Räume überstanden hast...");
				if (roomNumber >= 8) {
					System.out.printf("%n(Hausmeister)=> Tja, wahr wohl zu leicht...");
					coins = coins + 25;
				}
			}else if (Bet ==2) {
				System.out.printf("%n(Hausmeister)=> 50 Münzen  wenn du schon 16 Räume überstanden hast...");
				if (roomNumber >= 16) {
					System.out.printf("%n(Hausmeister)=> Tja, wahr wohl zu leicht...");
					coins = coins + 50;
				}
			}else if (Bet ==3) {
				System.out.printf("%n(Hausmeister)=> 75 Münzen  wenn du schon 24 Räume überstanden hast...");
				if (roomNumber >= 24) {
					System.out.printf("%n(Hausmeister)=> Tja, hätte ich nicht gedacht...");
					coins = coins + 75;
				}
			}else if (Bet ==4) {
				System.out.printf("%n(Hausmeister)=> 100 Münzen  wenn du schon 40 Räume überstanden hast...");
				if (roomNumber >= 40) {
					System.out.printf("%n(Hausmeister)=> Das haut mich wiklich aus den Latschen...");
					coins = coins + 100;
				}
			}
		}else if (antwort == 2) {
			System.out.printf("%n(Hausmeister)=> Nein...");
			System.out.printf("%n(Hausmeister)=> Naja...");
			System.out.printf("%n(Hausmeister)=> Heutzutage sind wirklich alle Verblödet...");
			System.out.printf("%n(Hausmeister)=> Hau ab!");
		}else {
			System.out.printf("%n(Hausmeister)=> Willst du mich bescheißen!?");
		}
		
		
	}
	//Regelt NPC.: Hausmeister '=fertig='
	//_________________________________________________________________________________________________________________________________________
	
	public static void npcBarkeeper() {
		
	int min = 1;
	int max = 4;
	int DrinkArt = (int)Math.floor(Math.random()*(max - min)) + min;
	
	System.out.printf("%nDu sprichst den Barkeeper an...");
	System.out.printf("%n");
	System.out.printf("%n(Barkeeper)=> Willst du einen Drink?");
	System.out.printf("%n(Barkeeper)=> Kostet nur 10 Münzen...");
	System.out.printf("%n(1 => ja/2 => nein)%n");
		int antwort = scanner.nextInt();
		
			if (antwort == 1) {
				coins = coins - 10;
				if (DrinkArt == 1) {
					System.out.printf("%n");
					System.out.printf("%n(Barkeeper)=> Ein Bier, kommt sofort");
					System.out.printf("%nEin paar sekunde vergehen...");
					System.out.printf("%n(Barkeeper)=> Hier bitte");
					System.out.printf("%nDas Bier sieh etwas Ranzig aus");
					System.out.printf("%nSicher, dass du es Trinken willst?");
					System.out.printf("%n(1 => ja/2 => nein)%n");
					int antwortZwei = scanner.nextInt();
					
					if (antwortZwei ==1) {
						System.out.printf("%ndir wirt so übel, dass du dich Diereckt übergibst...");
						System.out.printf("%n(Barkeeper)=> Neulinge könne nie das Bier verkraften...");
					}else if (antwortZwei == 2) {
						System.out.printf("%nAls der Barkeeper wieder beschäftigt ist, schleichst du zu einem Pfand automaten...");
						System.out.printf("%nDu leerst da 'Bier' über einem Abfluss aus und gibst die Flasche Zurück... ");
						coins = coins +15;
						System.out.printf("%nDu bekommst 15 Münzen zurück");
					}else {
						System.out.printf("%nDu wirfst mit es mit Kraft an die Wand...");
					}
					
				}else if (DrinkArt == 2) {
					System.out.printf("%n");
					System.out.printf("%n(Barkeeper)=> Einen Shot Whiskey, kommt sofort");
					System.out.printf("%nEin paar sekunde vergehen...");
					System.out.printf("%n(Barkeeper)=> Hier bitte");
				coinMultiplier = 1+1/2;
				}else if (DrinkArt == 3) {
					System.out.printf("%n");
					System.out.printf("%n(Barkeeper)=> Einen Vodka, kommt sofort");
					System.out.printf("%nEin paar sekunde vergehen...");
					System.out.printf("%n(Barkeeper)=> Hier bitte");
					VodkaActive = 1;
				}else if (DrinkArt == 4) {
					System.out.printf("%n");
					System.out.printf("%n(Barkeeper)=> Ein Bloody Mary, kommt sofort");
					System.out.printf("%nEin paar sekunde vergehen...");
					System.out.printf("%n(Barkeeper)=> Hier bitte");
				BloodyMaryActive = 1;
				}
			} else if (antwort == 2) {
				System.out.printf("%n(Barkeeper)=> Na gut...");
				System.out.printf("%n(Barkeeper)=> Viel glück...");
				System.out.printf("%n(Barkeeper)=> Du wirst es brauchen");
			} else {
				System.out.printf("%n(Barkeeper)=> So bekommst du nix!");
				System.out.printf("%n(Barkeeper)=> Also hör auf meine Zeit zu verschwenden und gib mir eine richtige Antwort...");
			
			}
		}
	
	//Regelt NPC.: Barkeeper '=fertig='
	//_________________________________________________________________________________________________________________________________________
	
	
	
	public static void npcCroupier() {
		System.out.printf("%nDu tretest näher... ");
		System.out.printf("%n(Croupier)=> ... ");
		System.out.printf("%n(Croupier)=> B-Brauchst du Hilfe mit Items? ");
		System.out.printf("%n(1 => ja/2 => nein) %n");
		int antwort = scanner.nextInt();
		
		if (antwort == 1) {
				System.out.printf("%n(Croupier)=> Welches Item? ");
				System.out.printf("%n(1 => Coinbeutel/2 => Billardkugel)");
				System.out.printf("%n(3 => Zufallswürfel/4 => Zigarre)");
				System.out.printf("%n(5 => PockerChips/6 => Papier - Kranich)");
				
				int antwortZwei = scanner.nextInt();
				
				if (antwortZwei == 1) {
					System.out.printf("%n(Croupier)=> Er erhöht das Münzenlimit um 100...");
				}else if (antwortZwei ==2) {
					System.out.printf("%n(Croupier)=> Man kann 8 Münzen opfern für noch einen zug im Kampf...");
				}else if (antwortZwei ==3) {
					System.out.printf("%n(Croupier)=> zu 50=% wird deinschaden im Kampf verzehnfacht, %noder mit 50% bekommst du selber 5 Herzen Schaden...");
				}else if (antwortZwei ==4) {
					System.out.printf("%n(Croupier)=> Gib dir im Kampf 3 Leben zurück");
				}else if (antwortZwei ==5) {
					System.out.printf("%n(Croupier)=> Sie setzen die Verteidigung auf 0");
				}else if (antwortZwei ==6) {
					System.out.printf("%n(Croupier)=> Mit Jeder verletzung von einem Blatt Papier steigt dein Schaden...");
				}else {
				System.out.printf("%n(Croupier)=> B-Bitte nochmal? ");
			}
			}else if (antwort == 2) {
			System.out.printf("%n(Croupier)=> N-Nein? ");
			System.out.printf("%n(Croupier)=> ok... ");
			System.out.printf("%nDer Croupier schaut bedrückt auf den Boden ... ");
		}else {
			System.out.printf("%n(Croupier)=> W-Was soll das bitteschön Hießen? ");
		}
		
		
	}
	//Regelt NPC.: Croupier '=fertig='
	//_________________________________________________________________________________________________________________________________________
	
	public static void npcHändler() {
		int min = 1;
		int max = 7;
		int Stock = (int)Math.floor(Math.random()*(max - min)) + min;
		int CostItem = 10 + (Etage*roomNumber)/RoomDifficulty;
		
		System.out.printf("%n");
		System.out.printf("%n(Händler)=> Willst du ein Item Kaufen?");
		System.out.printf("%n(Händler)=> Nur %d Münzen", CostItem );
		System.out.printf("%n(1 => ja/2 => nein)%n");
		int antwort = scanner.nextInt();
		
		if (antwort == 1) {
			Item = Stock;
			coins = coins - CostItem;
			if (Item == 1 ) {
				System.out.printf("%nDu bekommst einen Münzbeutel");
			}else if (Item == 2 ) {
				System.out.printf("%nDu bekommst eine Billardkugel");
			}else if (Item == 3 ) {
				System.out.printf("%nDu bekommst einen Zufallswürfel");
			}else if (Item == 4) {
				System.out.printf("%nDu bekommst eine Zigarre");
			}else if (Item == 5) {
				System.out.printf("%nDu bekommst ein paar PockerChips");	
			}else if (Item == 6) {
				System.out.printf("%nDu bekommst ein Kniffel - Set");
			}else if (Item == 7) {
				System.out.printf("%nDu bekommst einen Papier - Kranich");
			}
		}else if (antwort == 2) {
			System.out.printf("%n");
			System.out.printf("%n(Händler)=> Nagut, dein verlust...");
		}else {
			System.out.printf("%n(Händler)=> Was soll das bitte heißen?");
		}
		
		
	}
	//Regelt NPC.: Händler '=fertig='
	//_________________________________________________________________________________________________________________________________________
	public static void npcSpawn() {
		int min = 1;
		int max = 4;
		int npcType = (int)Math.floor(Math.random()*(max - min)) + min;
		
		if (npcType == 1) {
			System.out.printf("%n");
			System.out.printf("%nEs steht ein mysteriöser Händler vor dir...");
			System.out.printf("%nDu Fragst dich wie er hier hergekommen ist...");
			npcHändler();
		}else if (npcType == 2) {
			System.out.printf("%n");
			System.out.printf("%nDu findest dich im selben raum mit enem eher Lauch - Artigen Croupier...");
			System.out.printf("%nEr scheint dir Helfen zu wollen");
			npcCroupier();
		}else if (npcType == 3) {
			System.out.printf("%n");
			System.out.printf("%nDu Betretest eine ziemlich Heruntergekommene Bar... ");
			System.out.printf("%nund findest ein gut gekleideten, Zigaretten Rauchenden Barkeeper vor...");
			System.out.printf("%nDu solltest mit ihm reden...");
			npcBarkeeper();
		}else if (npcType == 4) {
			System.out.printf("%n");
			System.out.printf("%nDu findest dich in einem schlecht beleuchtetem Heizraum wieder...");
			System.out.printf("%nVor einem Heizkessel steht der Hausmeister...");
			System.out.printf("%nEr scheint mit dir reden zu wollen...");
			npcHausmeister();
		}
		
		
	}
	//Regelt NPCs '=fertig='
	//_________________________________________________________________________________________________________________________________________
	
	
	public static void Loot() {
		
			int max = 10;
			int min = 1;
			int Loot = (int)Math.floor(Math.random()*(max - min)) + min;
			LootComplete = Loot * LootMultiplier;
			
			coins = coins + LootComplete;
			System.out.printf("%nDu findest %d Münzen!",LootComplete);
			LootComplete = 0;
	}
	//Regelt die Gewinnung von Münzen '=fertig='
	//__________________________________________________________________________________________________________________________________________
	
	public static void LootRoom() {
		int antwort = 0;
		System.out.printf("%nDu betrittst einen Raum ohne sichtbare Gefahr...");
		while(!((antwort==1)||(antwort==2))) {
			System.out.printf("%nwillst du dich umsehen? (1 => ja/2 => nein)");
			antwort = scanner.nextInt();
			if (antwort==1) {
				int max = 10;
				int min = 1;
				int LootChance = (int)Math.floor(Math.random()*(max - min)) + min;
				if (LootChance >= 3) {
				Loot();
				}else {
					heart--;
					System.out.printf("%nDu hast dich an einem Blatt Papier Geschnitten!");
					PaperCut++;
					
			}
			} else if (antwort == 2) {
			System.out.printf("%nDu entschidest dich dafür in den nächsten raum zu gehen...");
			
			}else {
			System.out.printf("%nbitte gib eine richtige antwort!");
			}
		}
	}
	//Regelt den Unbesonderen Raum '=fertig='
	//__________________________________________________________________________________________________________________________________________
	
	public static void RaumLaden() {
		
		roomNumber++;
		
		BossDealer();
		BossKingPin();
		int min = 1;
		int max = 10;
		int AmbushChance = (int)Math.floor(Math.random()*(max - min)) + min;
		
		int npcChance = (int)Math.floor(Math.random()*(max - min)) + min;
		
		int TreppeChance = (int)Math.floor(Math.random()*(max - min)) + min;
		
		if (TreppeChance >= 9) {
			System.out.printf("%n");
			System.out.printf("%nDu siehst eie Treppe im Raum...");
			System.out.printf("%nDu steigst sie schnell hinauf, währen du an deine Familie denkst...");
			System.out.printf("%nDie Treppe füht auf die nächste Etage");
			Etagen();
		}else if (AmbushChance >= 4) {
			GegnerSpawn();
		}else if (npcChance >= 7 ) {
		npcSpawn();	
		} else {
			LootRoom();
			
		}
		
	}
	//Ladet Raum  (Gegner, NPCs, Loot) oder Treppe '=fertig='
	//_______________________________________________________________________________________________________________________________________
	
	//System.out.printf("%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠤⣒⣒⡲⢄%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⢻⠃⠁⡍⢹⡏⣇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼⢸⣇⠇⠑⣸⣷⡏%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣗⣻⣿⢛⢻⣿⣿⡇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣷⣟⣬⣎⡇⢎⣿⡇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣷⣻⠶⣬⣜⣷⣾⡇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⢷⠛⡛⢓⠛⡲⣛⣇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡘⢇⠒⡐⠈⠴⠡⡜⣧%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡏⡅⠢⠄⠡⣄⡓⡜⣷%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣧⡴⡗⠾⢒⠮⠽⣶⢿%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⢧⣾⢟⣹⣟⣳⠾⣽⣿%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⢸⣾⣿⣿⣯⣽⣦⣿⣽⣿⠆%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣾⡿⢟⡻⢝⣻⣿⣿⣏⡟⣿⣿⣚⣽⣿⣽⠂%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠿⡙⢡⠹⠃⠄⠂⢈⣿⣯⣋⣝⣛⠛⡙⢻⡟⣾⢀⣤⠶⡒⣶⢲⠲⣄%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡏⢆⡑⢪⠐⡉⢀⠂⠤⣿⣸⡏⣑⣮⡛⠑⡢⣛⣿⡿⠀⠌⢙⡚⣻⢿⣭⣧%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼⢈⠶⡽⡱⣰⠃⠄⠀⣘⣿⣽⡞⡍⣂⠔⡨⠔⣹⣿⠲⠀⠈⠂⢌⠡⢣⣍⣓⡇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣇⢯⣷⢗⣽⠕⣇⢂⡴⢸⣿⣷⣚⠯⡄⢎⠰⣉⠼⣿⠐⠠⠁⠐⠈⣄⣷⡼⢢⣿⣀⡀%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡏⣾⣿⠿⣣⢓⣯⣴⣋⣼⡿⣟⡳⡭⠝⢢⡑⢢⢻⣿⡉⠄⠀⠸⢟⣾⢋⣷⢸⣿⣿⣻⡝⡶⢤⡀%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣽⣿⣞⣿⣭⣟⢺⣿⣿⣿⢧⣸⣽⣿⣢⡌⢣⢳⡻⡷⡌⢠⢣⣏⣻⣦⢟⣸⣿⠡⠀⠈⠝⣿⣿⣦⡀%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⢿⣼⣿⣽⣿⣿⣮⣿⣿⣯⡿⣿⣿⣯⣻⣷⣿⣈⣷⢿⣿⣔⡨⢽⣮⡇⡽⣼⢸⣿⠐⠀⢈⠰⣸⣽⣿⡇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣼⣾⣿⣿⣿⣿⣿⣿⣧⣽⣿⣷⣿⣿⣟⣿⣿⣾⣷⣼⣹⣿⣿⣻⣿⡿⣏⢣⡳⠾⣿⠠⠀⠠⢡⣼⣿⣶⡿%n⠀⠀⠀⠀⠀⠀⠀⣀⣠⣾⢃⣾⢿⣿⣼⣿⣿⣿⣻⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⢿⣽⣿⣿⣿⣿⣿⣿⢿⣮⣹⡧⣿⡤⢘⣄⣷⣿⣿⣯⣿%n⠀⠀⢀⣠⡴⠒⣛⢁⠞⠋⢨⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣻⣿⣿⣿⣮⣿⣿⡿⣿⣿⣍⣿⣿⣿⣿⣿⡷%n⢀⣴⣟⡖⢪⠥⠤⠒⢤⣀⣿⣿⣿⣿⡿⣿⣿⣿⣾⣿⣿⣿⣟⡯⡿⣿⣿⣻⡿⣽⣿⣿⣿⣝⣿⣿⣟⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⢻⠿⣿%n⠘⡭⣅⠒⡀⠂⠄⠀⠀⠈⣿⢻⣭⣿⣽⢺⣻⣿⣿⣽⣫⠔⣧⡚⣷⢿⠟⣿⣿⣿⣾⡻⠷⠽⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣟⣿⢿⣻%n⠀⣷⢌⠳⢈⠁⢀⠀⠀⢰⠿⣋⠧⢾⢏⢾⣻⣽⣿⣶⣩⡟⣸⡍⡝⢻⢛⣿⠟⣯⢱⡐⢩⣲⣿⣿⢾⣿⡧⠮⣏⣿⣿⣿⣿⣾⣿⣿⣞⣿⡆%n⠀⢸⡮⣍⠣⠄⡀⠤⠢⣿⡁⠆⠅⠆⠻⠮⣿⡻⣿⣷⣻⣷⠟⡽⠒⣥⣫⡼⢟⡡⡏⣞⢠⣷⢾⣓⠾⣻⡥⡿⠽⣿⣿⣿⣿⣿⣽⢿⣽⣾⠁%n⠀⠀⢿⡯⡽⠵⣫⠥⣼⠣⠔⡉⡐⢌⠣⢁⠫⢶⣿⣿⣿⣿⡽⣿⠣⡵⠯⢵⢮⢶⣭⠹⡶⢎⡗⣌⡣⣱⠹⡎⣷⠹⡿⣿⠿⣧⢝⣿⣿⣿%n⠀⠀⠘⣿⣷⣟⣥⡞⣟⡸⡐⠠⡱⣨⡄⡼⡜⢹⣡⣿⣿⣿⢶⢣⣾⣥⠷⣝⡛⣫⠴⣻⢏⢷⡎⡴⢹⡌⢷⣙⠬⣳⢟⣫⣽⢚⣿⣿⣿⣿%n⠀⠀⠀⢻⣿⣿⣏⢧⡷⢴⠉⣄⡿⢡⣸⣱⢋⣟⢳⣴⣿⣿⣿⣏⣱⣌⠶⣋⡽⣯⡹⢟⡋⣅⢊⡵⢫⣜⡧⡜⣶⣋⣾⣿⣳⣿⣿⣿⣿⣿%n⠀⠀⠀⠘⣿⣿⣿⣿⢳⡎⣗⣺⢜⡟⣳⣻⣘⣿⢛⣿⣿⣿⣟⡭⢖⡋⠶⣥⡿⣉⣑⡪⢵⠤⢫⠸⢳⣉⣧⣿⢟⣿⣟⣾⣫⣿⣿⣿⣿⣿%n⠀⠀⠀⠀⠹⣿⣿⣿⣷⣿⣯⡿⣾⡽⣳⢯⣿⢾⣭⢻⣾⡿⣏⡛⣆⡟⢩⠒⡷⢡⣥⢞⡐⢎⠂⣏⡝⢪⡼⣴⡟⣻⣿⣾⣿⣿⣿⣿⣿⣿%n⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣸⣿⢷⣏⣿⣷⣿⡿⣱⠞⡼⢭⡒⣻⢒⣠⣎⣁⡯⢢⡼⠟⣽⣁⡟⣥⣿⣿⣿⣻⣿⣿⣿⡿%n⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣏⣿⣿⣿⢻⡽⢓⣮⣷⡯⢖⣳⣓⣩⢷⡯⣶⣿⣷⡟⣵⣿⡻⠟⣱⢿⣿⣿⣿⡇%n⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⡿⣷⢿⣻⣞⣶⣯⣿⣾⢭⢾⡽⣺⡿⡶⣏⣽⣿⠏⣇⣚⣼⣻⣿⣿⣿%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣮⡵⣿⡿⠞⣿⣩⣽⠟⣺⢝⣷⣷⢫⠟⡥⢋⣼⣶⣿⣿⣿⣿⡟%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⠿⣏⣿⣿⣿⣿⣭⣷⡿⣫⢖⡽⠧⡾⣧⣾⣟⣾⣿⣿⣿⠇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣾⣿⣿⣾⣷⣾⣳⣯⣽⣷⣵⣞⣿⣿⣷⣿⣿⣽⣿⣿⡟%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣛⣯⣿⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣷⣿⣿⣿⣿⡾⣿⡿⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡿⣟⣽⣿⠿⣿⡷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣻⢾⣿⣿⣟⣻⣹⣞⣿⣿⣻⣿⣿⣿⣿⣿⣿⣿⣿⡟%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⠿⠿⠛⠛⠛⠉⠉⠉⠁⠈⠀⠀⠀⠈⠈⠉⠉⠉⠙⠛⠛⠻⠿⢿⣿⣏%n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠀⠀");
	//sehr wichtig, nicht löschen!
	
	public static void main(String[]args) {
	
		begruessung();
		Etagen();
		while(gameRunning == 1  && heart > 0) {
			
			
			raumBetreten();
			RaumLaden();
		}
		if (gameRunning == 2) {
		spielEndeSchlecht();
		}else if (gameRunning == 3) {
			spielEndeGut();
		}
		scanner.close();
	}
 
	
}